import xbmc
import xbmcaddon
import json
import urllib.request
from urllib.parse import urlencode

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwoPd6x37Wy17c5HuMnLO1l8Dmb9bVtemhOI0dcAxnZ7Jwz3sy9qt-KvO__ZPSdz7roMQ/exec"


def get_country():
    try:
        req = urllib.request.Request(
            "https://ipinfo.io/json",
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
            return data.get("country", "Desconocido")
    except:
        return "Desconocido"


def send_install_data(build_name="plugin.program.latinboy", version="N/A"):
    try:
        country = get_country()

        params = {
            "pais": country,
            "build": build_name,
            "version": version
        }

        url = GOOGLE_SCRIPT_URL + "?" + urlencode(params)

        req = urllib.request.Request(
            url,
            headers={'User-Agent': 'Mozilla/5.0'}
        )
        urllib.request.urlopen(req, timeout=10)

        xbmc.log(f"[{ADDON_ID}] Registro enviado: {country} | {build_name} | {version}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Error analytics: {e}", xbmc.LOGERROR)
