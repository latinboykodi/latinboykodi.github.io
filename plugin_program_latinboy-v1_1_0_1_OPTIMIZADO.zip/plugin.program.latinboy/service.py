# -*- coding: utf-8 -*-
import xbmc
from resources.lib.modules._service import Startup

class Service(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.startup = Startup()

    def run(self):
        xbmc.log("[LatinBoy] Service started", xbmc.LOGINFO)

        # Ejecutar startup una vez al iniciar Kodi
        try:
            self.startup.run_startup()
        except Exception as e:
            xbmc.log(f"[LatinBoy] Startup error: {e}", xbmc.LOGERROR)

        # Mantener el servicio activo
        while not self.abortRequested():
            # Espera 10 minutos
            if self.waitForAbort(600):
                break


if __name__ == "__main__":
    Service().run()
