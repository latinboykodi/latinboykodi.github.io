################################################################################
#  pvr_install.py - Auto-instalador de pvr.iptvsimple para plugin.program.latinboy
#  Adaptado del helper de inputstream binarios (mirrors.kodi.tv)
################################################################################

import os
import re
import time
import zipfile
import sqlite3
import threading
from datetime import datetime
from xml.etree import ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

# Dependencias "core" que ya vienen con Kodi y NUNCA se instalan como addon aparte
CORE_DEPS = {
    'xbmc.python', 'xbmc.gui', 'xbmc.core', 'xbmc.addon', 'xbmc.pvr',
    'xbmc.json', 'xbmc.metadata', 'kodi.binary.instance.pvr',
    'kodi.binary.instance.audiodecoder', 'kodi.binary.global.main',
}

try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

from urllib.request import Request, urlopen

from .addonvar import addons_path, addons_db, home, packages

PVR_ADDON_ID = 'pvr.iptvsimple'
KODI_MIRROR_BASE = 'https://mirrors.kodi.tv/addons/'


def get_kodi_codename():
    ver = xbmc.getInfoLabel('System.BuildVersion')
    try:
        major = int(str(ver).split('.')[0])
    except (ValueError, IndexError):
        major = 0
    return {22: 'piers', 21: 'omega', 20: 'nexus', 19: 'matrix'}.get(major)


def get_platform_suffix():
    os_name = xbmc.getInfoLabel('System.OSVersionInfo') or ''
    plat = (xbmc.getInfoLabel('System.Platform') or '').lower()
    # xbmc no expone platform() directo; usamos variables de entorno / módulos estándar
    import platform as py_platform
    system = py_platform.system().lower()
    machine = py_platform.machine().lower()

    if 'android' in os_name.lower() or os.environ.get('XBMC_ANDROID_SYSTEM_LIBS'):
        return 'android-aarch64' if 'aarch64' in machine or 'arm64' in machine else 'android-armv7'
    if system == 'windows':
        return 'windows-x86_64' if '64' in py_platform.architecture()[0] else 'windows-i686'
    if system == 'linux':
        if 'aarch64' in machine or 'arm64' in machine:
            return 'linux-aarch64'
        if 'arm' in machine:
            return 'linux-armv7'
        return 'linux-x86_64'
    if system == 'darwin':
        return 'osx-arm64' if 'arm64' in machine else 'osx-x86_64'
    return None


def _open_url(url):
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    return urlopen(req, timeout=15)


def get_mirror_url(addon_id):
    codename = get_kodi_codename()
    plat = get_platform_suffix()
    if not codename or not plat:
        xbmc.log(f'[pvr_install] No se pudo determinar codename/plataforma ({codename}, {plat})', xbmc.LOGWARNING)
        return None
    return urljoin(urljoin(KODI_MIRROR_BASE, codename + '/'), f'{addon_id}+{plat}/')


def fetch_latest_zip_url(mirror_url, addon_id):
    try:
        html = _open_url(mirror_url).read().decode('utf-8', errors='ignore')
        pattern = re.compile(r'href="(' + re.escape(addon_id) + r'-\d+\.\d+\.\d+\.zip)"')
        matches = pattern.findall(html)
        if not matches:
            return None

        def verkey(fn):
            m = re.search(r'(\d+)\.(\d+)\.(\d+)', fn)
            return tuple(int(x) for x in m.groups()) if m else (0, 0, 0)

        matches.sort(key=verkey, reverse=True)
        return urljoin(mirror_url, matches[0])
    except Exception as e:
        xbmc.log(f'[pvr_install] Error obteniendo listado del mirror: {e}', xbmc.LOGERROR)
        return None


def is_installed(addon_id=PVR_ADDON_ID):
    return os.path.exists(os.path.join(addons_path, addon_id, 'addon.xml'))


def enable_addon_sqlite(addon_id=PVR_ADDON_ID):
    try:
        ts = str(datetime.now())[:-7]
        con = sqlite3.connect(addons_db)
        con.execute(
            'INSERT or IGNORE into installed (addonID, enabled, installDate) VALUES (?,?,?)',
            (addon_id, 1, ts)
        )
        con.execute('UPDATE installed SET enabled = ? WHERE addonID = ?', (1, addon_id))
        con.commit()
        con.close()
        return True
    except sqlite3.Error as e:
        xbmc.log(f'[pvr_install] Error SQLite activando {addon_id}: {e}', xbmc.LOGERROR)
        return False


def get_addon_requires(addon_id):
    """Lee el addon.xml ya instalado y devuelve la lista de dependencias declaradas."""
    addon_xml = os.path.join(addons_path, addon_id, 'addon.xml')
    if not os.path.exists(addon_xml):
        return []
    try:
        root = ET.parse(addon_xml).getroot()
        requires = root.find('requires')
        if requires is None:
            return []
        deps = []
        for imp in requires.findall('import'):
            dep_id = imp.get('addon')
            if dep_id and dep_id not in CORE_DEPS:
                deps.append(dep_id)
        return deps
    except Exception as e:
        xbmc.log(f'[pvr_install] Error leyendo requires de {addon_id}: {e}', xbmc.LOGERROR)
        return []


def ensure_dependencies(addon_id, _seen=None):
    """Instala recursivamente cualquier dependencia declarada que falte, respetando plataforma."""
    if _seen is None:
        _seen = set()
    if addon_id in _seen:
        return True
    _seen.add(addon_id)

    all_ok = True
    for dep_id in get_addon_requires(addon_id):
        if is_installed(dep_id):
            enable_addon_sqlite(dep_id)
            ensure_dependencies(dep_id, _seen)
            continue

        xbmc.log(f'[pvr_install] Dependencia faltante detectada: {dep_id} (requerida por {addon_id})', xbmc.LOGINFO)

        # Intento 1: mirror directo (silencioso, sin dialogos)
        ok = download_and_extract(dep_id)
        # Intento 2: repo oficial, solo si el mirror no tiene ese addon disponible
        if not ok:
            ok = install_addon_via_repo(dep_id)

        if ok:
            ensure_dependencies(dep_id, _seen)
        else:
            xbmc.log(f'[pvr_install] No se pudo instalar la dependencia {dep_id}', xbmc.LOGWARNING)
            all_ok = False

    return all_ok


def download_and_extract(addon_id=PVR_ADDON_ID):
    mirror_url = get_mirror_url(addon_id)
    if not mirror_url:
        return False

    zip_url = fetch_latest_zip_url(mirror_url, addon_id)
    if not zip_url:
        xbmc.log(f'[pvr_install] No se encontro zip para {addon_id} en {mirror_url}', xbmc.LOGWARNING)
        return False

    if not os.path.exists(packages):
        os.makedirs(packages)
    zip_path = os.path.join(packages, f'{addon_id}_tmp.zip')

    try:
        resp = _open_url(zip_url)
        with open(zip_path, 'wb') as f:
            while True:
                chunk = resp.read(512 * 1024)
                if not chunk:
                    break
                f.write(chunk)

        if not os.path.exists(zip_path) or os.path.getsize(zip_path) == 0:
            raise Exception('Descarga vacia o fallida')

        with zipfile.ZipFile(zip_path, 'r') as z:
            z.extractall(addons_path)

        os.unlink(zip_path)

        if is_installed(addon_id):
            enable_addon_sqlite(addon_id)
            xbmc.log(f'[pvr_install] {addon_id} instalado y activado correctamente', xbmc.LOGINFO)
            return True
        xbmc.log(f'[pvr_install] {addon_id} no aparecio tras extraer el zip', xbmc.LOGERROR)
        return False

    except Exception as e:
        xbmc.log(f'[pvr_install] Error instalando {addon_id}: {e}', xbmc.LOGERROR)
        if os.path.exists(zip_path):
            try:
                os.unlink(zip_path)
            except OSError:
                pass
        return False


def install_addon_via_repo(addon_id=PVR_ADDON_ID, timeout=30):
    """Alternativa simple: pide a Kodi que lo instale desde el repo oficial ya configurado."""
    if is_installed(addon_id):
        return True
    xbmc.executebuiltin(f'InstallAddon({addon_id})')
    clicked = False
    start = time.time()
    while time.time() < start + timeout:
        xbmc.sleep(300)
        if xbmc.getCondVisibility('Window.IsTopMost(yesnodialog)') and not clicked:
            xbmc.executebuiltin('SendClick(yesnodialog, 11)')
            clicked = True
        if xbmc.getCondVisibility(f'System.HasAddon({addon_id})'):
            return True
    return False


def wait_for_pvr_install(max_wait=240, poll_interval=5, message_switch_seconds=4):
    """Ejecuta la instalacion en segundo plano y muestra un DialogProgress cuya barra
    avanza segun el TIEMPO REAL transcurrido (no segun el numero de intento), para
    que no de sensacion de que se colgo. El texto alterna entre dos mensajes fijos.

    No devuelve el control hasta confirmar la instalacion en disco, o hasta agotar
    max_wait segundos. Llamar ANTES de enable_wizard()/os._exit(1) en build_install.py.
    """
    messages = [
        'Instalando addons necesarios...\nNo cierres Kodi, se cerrara solo al terminar.',
        'Instalando addons, espera...\nKodi se reiniciara solo.',
    ]

    state = {'done': False, 'success': False}

    def _worker():
        worker_start = time.time()
        while True:
            ok = ensure_pvr_iptvsimple()
            if is_installed(PVR_ADDON_ID) and ok:
                state['success'] = True
                break
            if time.time() - worker_start >= max_wait:
                break
            time.sleep(poll_interval)
        state['done'] = True

    worker = threading.Thread(target=_worker)
    worker.daemon = True
    worker.start()

    progress = xbmcgui.DialogProgress()
    progress.create('Instalando addons', messages[0])

    start = time.time()
    msg_index = 0
    last_switch = start
    result = False

    try:
        while not state['done']:
            elapsed = time.time() - start
            if elapsed >= max_wait:
                break

            if time.time() - last_switch >= message_switch_seconds:
                msg_index = (msg_index + 1) % len(messages)
                last_switch = time.time()

            pct = min(int((elapsed / max_wait) * 100), 99)
            progress.update(pct, messages[msg_index])
            xbmc.sleep(500)

        if state['success']:
            xbmc.log(f'[pvr_install] {PVR_ADDON_ID} confirmado instalado tras {int(time.time()-start)}s', xbmc.LOGINFO)
            progress.update(100, 'Instalacion completa.')
            xbmc.sleep(800)
            result = True
        else:
            worker.join(timeout=3)  # pequena gracia por si el worker esta a punto de terminar
            if is_installed(PVR_ADDON_ID):
                enable_addon_sqlite(PVR_ADDON_ID)
                xbmc.log(f'[pvr_install] {PVR_ADDON_ID} presente en disco tras timeout, activado igual', xbmc.LOGWARNING)
                result = True
            else:
                xbmc.log(f'[pvr_install] TIMEOUT: {PVR_ADDON_ID} no se pudo confirmar tras {max_wait}s. '
                          f'Se continua igual para no bloquear el wizard.', xbmc.LOGERROR)
    finally:
        progress.close()

    return result


def ensure_pvr_iptvsimple():
    """Punto de entrada: llamar desde build_install.py al terminar la instalacion del build.

    Instalacion 100% silenciosa: no requiere interaccion del usuario.
    Prioridad: mirror directo (sin UI) -> repo oficial (solo si el mirror falla).
    """
    installed_ok = False

    if is_installed(PVR_ADDON_ID):
        enable_addon_sqlite(PVR_ADDON_ID)
        installed_ok = True
    elif download_and_extract(PVR_ADDON_ID):
        # 1) Metodo silencioso: descarga directa desde mirrors.kodi.tv (sin dialogos)
        installed_ok = True
    else:
        # 2) Fallback solo si el mirror fallo (puede llegar a mostrar un dialogo)
        xbmc.log(f'[pvr_install] Mirror fallo, probando InstallAddon como ultimo recurso', xbmc.LOGWARNING)
        installed_ok = install_addon_via_repo(PVR_ADDON_ID)

    if not installed_ok:
        xbmc.log(f'[pvr_install] No se pudo instalar {PVR_ADDON_ID} por ningun metodo', xbmc.LOGERROR)
        return False

    # Resolver dependencias declaradas en su addon.xml (mismo criterio: silencioso primero)
    deps_ok = ensure_dependencies(PVR_ADDON_ID)
    xbmc.executebuiltin('UpdateLocalAddons')

    return installed_ok and deps_ok
