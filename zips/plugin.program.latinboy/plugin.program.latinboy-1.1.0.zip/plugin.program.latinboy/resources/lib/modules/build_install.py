import os
import json
from datetime import datetime
import time
import sqlite3
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from pathlib import Path
from datetime import datetime
import shutil
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from .downloader import Downloader
from .save_data import save_backup_restore
from .maintenance import fresh_start, clean_backups, truncate_tables, skin_override, skin_override_disable
from .addonvar import dp, dialog, zippath, addon_name, addon_icon, addon_id, home, setting, setting_set, local_string, addons_db, gui_temp_dir, gui_temp_file, advancedsettings_backup, NEW_BUILD
from .colors import colors

COLOR1 = colors.color_text1
COLOR2 = colors.color_text2

date_time = datetime.now()
date = date_time.strftime('%Y-%m-%d')
addons_path = Path(xbmcvfs.translatePath('special://home/addons'))
user_data = Path(xbmcvfs.translatePath('special://userdata'))
binaries_path = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))) / 'binaries.json'

def build_install(name, name2, version, url):
    # Ready to install, Cancel, Continue
    if not dialog.yesno(
        COLOR2(name),
        COLOR2(local_string(30028)),
        nolabel=local_string(30029),
        yeslabel=local_string(30030)
    ):
        return
    download_build(name, url)
    if name2 in [setting('buildname'),  NEW_BUILD]:
        save_backup_restore('backup')
    elif setting('skin_protection') == 'true':
        setting_set('saveadvanced', 'true')
        skin_override_disable()
        save_backup_restore('backup')
    else:
        save_backup_restore('backup')
    fresh_start()
    if name2 in [setting('buildname'),  NEW_BUILD]:
        pass
    else:
        extract_gui()
    extract_build()
    if name2 in [setting('buildname'),  NEW_BUILD]:
        save_backup_restore('restore_gui')
    elif name2 != setting('buildname') and name2 != NEW_BUILD and setting('skin_protection') == 'true' and setting('saveadvanced') == 'true':
        if xbmcvfs.exists(gui_temp_file):
            tree = ET.parse(gui_temp_file)
            root = tree.getroot()
            for gui_setting in root:
                name = gui_setting.get('id')
                if name == 'lookandfeel.skin':
                    skin = gui_setting.text  
        skin_override(skin, advancedsettings_backup)
        save_backup_restore('restore')
    else:
        save_backup_restore('restore')
    clean_backups()
    setting_set('buildname', name2)
    setting_set('buildversion', version)
    setting_set('buildinstalled', date)
    setting_set('update_passed', 'false')
    setting_set('firstrun', 'true')
    #check_binary()
    install_binary_addons()
    enable_wizard()
    if name2 == 'ELEMico':
        xbmcgui.Dialog().notification(addon_name, 'Build Install Complete!', addon_icon, 3000)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification(addon_name, 'Force Closing Kodi!', addon_icon, 3000)
        xbmc.sleep(3500)
        os._exit(1)
    else:
        truncate_tables()
        xbmcgui.Dialog().notification(addon_name, 'Build Install Complete!', addon_icon, 3000)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification(addon_name, 'Force Closing Kodi!', addon_icon, 3000)
        xbmc.sleep(3500)
        os._exit(1)

def download_build(name, url):
    if os.path.exists(zippath):
        os.unlink(zippath)
    d = Downloader(url)
    d.download_build(name, zippath)

def extract_build():
    if os.path.exists(zippath):
        dp.create(addon_name, local_string(30034))  # Extracting files
        counter = 1
        with ZipFile(zippath, 'r') as z:
            files = z.infolist()
            for file in files:
                filename = file.filename
                filename_path = os.path.join(home, filename)
                progress_percentage = int(counter/len(files)*100)
                try:
                    if not os.path.exists(filename_path) or 'Addons33.db' in filename:
                        z.extract(file, home)
                except Exception as e:
                    xbmc.log(f'Error extracting {filename} - {e}', xbmc.LOGINFO)
                dp.update(progress_percentage, f'{local_string(30034)}...\n{progress_percentage}%\n{filename}')
                counter += 1
        dp.update(100, local_string(30035))  # Done Extracting
        xbmc.sleep(500)
        dp.close()
        os.unlink(zippath)

def extract_gui():
    if os.path.exists(zippath):
        os.mkdir(gui_temp_dir)
        with ZipFile(zippath) as z:
            with open(gui_temp_file, 'wb') as f:
                try:
                    f.write(z.read('userdata/guisettings.xml'))
                except Exception as e:
                    xbmc.log(f'Error extracting guisettings.xml - {e}', xbmc.LOGINFO)

def sync_addon_repos():
    # Fuerza que Kodi refresque el indice de addons disponibles en los
    # repos habilitados. Necesario porque fresh_start() puede resetear
    # Addons33.db, y sin esto Kodi puede no "ver" el addon todavia.
    xbmc.log(f'[{addon_name}] Syncing addon repositories...', xbmc.LOGINFO)
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.sleep(5000)

def addon_is_installed(plugin_id):
    # System.HasAddon() a veces no detecta bien librerias tipo
    # script.module.* recien instaladas. Usamos tambien
    # Addons.GetAddonDetails (metodo JSON-RPC real, a diferencia de
    # InstallAddon) como verificacion mas confiable.
    if xbmc.getCondVisibility(f'System.HasAddon({plugin_id})'):
        return True
    request = {
        "jsonrpc": "2.0",
        "method": "Addons.GetAddonDetails",
        "params": {"addonid": plugin_id, "properties": ["enabled"]},
        "id": 1
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        return 'result' in response and 'addon' in response['result']
    except Exception:
        return False

def install_addon_builtin(plugin_id):
    # Addons.InstallAddon NO existe como metodo en la API JSON-RPC de
    # Kodi (en ninguna version). El mecanismo real y correcto para
    # instalar un addon de forma programatica es el builtin InstallAddon().
    # InstallAddon() puede mostrar un dialogo de confirmacion Si/No -
    # a veces mas de una vez por addon (ej. una para el addon principal
    # y otra para sus dependencias). Dialog.Close(yesnodialog,true) NO
    # simula un clic en "Si", solo fuerza el cierre sin confirmar, lo
    # cual deja la instalacion colgada. Hay que usar SendClick apuntando
    # al control "Yes" (id 11 en skin Estuary), y repetirlo cada vez que
    # el dialogo reaparezca.
    xbmc.log(f'[{addon_name}] Installing {plugin_id} via executebuiltin...', xbmc.LOGINFO)
    xbmc.executebuiltin(f'InstallAddon({plugin_id})')
    start = time.time()
    timeout = 60
    last_logged_window = None
    while not addon_is_installed(plugin_id):
        if time.time() >= start + timeout:
            return False

        current_window = xbmc.getInfoLabel('System.CurrentWindow')
        current_control = xbmc.getInfoLabel('System.CurrentControl')
        if current_window != last_logged_window:
            xbmc.log(f'[{addon_name}] Waiting on {plugin_id} - active window: "{current_window}" control: "{current_control}"', xbmc.LOGINFO)
            last_logged_window = current_window

        if xbmc.getCondVisibility('Window.IsActive(yesnodialog)') or xbmc.getCondVisibility('Window.IsTopMost(yesnodialog)'):
            xbmc.log(f'[{addon_name}] Yes/No dialog detected for {plugin_id}, clicking Yes...', xbmc.LOGINFO)
            xbmc.executebuiltin('SendClick(yesnodialog, 11)')
            xbmc.sleep(300)

        xbmc.sleep(500)
    return True

def install_binary_addons():
    # Instala automaticamente (sin dialogos) los addons con binarios
    # correctos para el OS/arquitectura del dispositivo, en vez de
    # empaquetarlos dentro del zip del build.
    binary_addons = [
        'inputstream.adaptive',
        'pvr.iptvsimple',
        'script.module.inputstreamhelper'
    ]

    if not xbmc.getCondVisibility('System.InternetState'):
        xbmc.log(f'[{addon_name}] No internet - skipping binary addon install', xbmc.LOGWARNING)
        return

    sync_addon_repos()

    dp.create(addon_name, 'Installing required components...')
    total = len(binary_addons)
    for i, plugin_id in enumerate(binary_addons):
        progress = int((i / total) * 100)
        dp.update(progress, f'Installing {plugin_id}...')

        if addon_is_installed(plugin_id):
            xbmc.log(f'[{addon_name}] {plugin_id} already installed, skipping', xbmc.LOGINFO)
            continue

        success = install_addon_builtin(plugin_id)
        if success:
            xbmc.log(f'[{addon_name}] {plugin_id} installed successfully', xbmc.LOGINFO)
        else:
            xbmc.log(f'[{addon_name}] Timeout installing {plugin_id}', xbmc.LOGWARNING)

    dp.update(100, 'Components installed')
    xbmc.sleep(500)
    dp.close()

'''def check_binary():
    binary_list = []
    for folder in addons_path.iterdir():
        if folder.is_dir():
            addon_xml = folder / 'addon.xml'
            if addon_xml.exists():
              with open(addon_xml, 'r', encoding='utf-8', errors='ignore') as f:
                  _xml = f.read()
              if 'kodi.binary' in _xml:
                  try:
                      root = ET.fromstring(_xml)
                      binary_list.append(root.attrib['id'])
                  except:
                      binary_list.append(folder.name)
                  try:
                      shutil.rmtree(folder)
                  except PermissionError as e:
                      xbmc.log(f'Unable to delete binary {folder} - {e}')
    if len(binary_list) > 0:
        with open(binaries_path, 'w', encoding='utf-8') as f:
            json.dump({'items': binary_list}, f, indent = 4)

def restore_binary():
    with open(binaries_path, 'r', encoding='utf-8', errors='ignore') as f:
        binaries_list = json.loads(f.read())['items']
    failed = []
    for plugin_id in binaries_list:
        install = install_addon(plugin_id)
        if install is not True:
            failed.append(plugin_id)
    if len(failed) == 0:
        binaries_path.unlink()
    else:
        with open(binaries_path, 'w', encoding='utf-8') as f:
            json.dump({'items': failed}, f, indent = 4)

def install_addon(plugin_id):
    if xbmc.getCondVisibility(f'System.HasAddon({plugin_id})'):
        return True
    xbmc.executebuiltin(f'InstallAddon({plugin_id})')
    clicked = False
    start = time.time()
    timeout = 20
    while not xbmc.getCondVisibility(f'System.HasAddon({plugin_id})'):
        if time.time() >= start + timeout:
            return False
        xbmc.sleep(500)
        if xbmc.getCondVisibility('Window.IsTopMost(yesnodialog)') and not clicked:
            xbmc.executebuiltin('SendClick(yesnodialog, 11)')
            clicked = True
    return True
# Binaries inspired Dr. Infernoo'''

def enable_wizard():
    try:
        timestamp = str(datetime.now())[:-7]

        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('INSERT or IGNORE into installed (addonID , enabled, installDate) VALUES (?,?,?)', (addon_id, 1, timestamp,))

        cursor.execute('UPDATE installed SET enabled = ? WHERE addonID = ? ', (1, addon_id,))
        con.commit()
    except sqlite3.Error as e:
        xbmc.log('There was an error writing to the database - %s' %e, xbmc.LOGINFO)
        return
    finally:
        try:
            if con:
                con.close()
        except UnboundLocalError as e:
            xbmc.log('%s: There was an error connecting to the database - %s' % (xbmcaddon.Addon().getAddonInfo('name'), e), xbmc.LOGINFO)
