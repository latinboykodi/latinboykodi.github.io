import os
import sys
import json
import xbmc
import xbmcgui
import xbmcplugin
import urllib
import urllib.request
from .utils import add_dir
from .colors import colors
from .db import lastchk
from uservar import buildfile, videos_url, changelog_dir
from .parser import XmlParser, TextParser, get_page
from .addonvar import (addon_name, setting, addon_icon, addon_fanart, addon_ver, local_string, translatePath,
                       authorize, kodi_ver, kodi_versions, chk_splash, chk_skin_override, quick_stats, headers, home,
                       os_info, cur_skin, uptime, total_uptime, build_ver, build_date, vid_list, prg_list, repo_list,
                       inst_date, UPDATE_VERSION, CURRENT_BUILD, BUILD_VERSION, BUILD_NAME, NUM_BUILDS
                       )

HANDLE = int(sys.argv[1])

COLOR1 = colors.color_text1
COLOR2 = colors.color_text2
COLOR3 = colors.color_text3
COLOR4 = colors.color_text4

# Builds cache
cache_file = translatePath("special://profile/addon_data/plugin.program.latinboy/builds_cache.json")


def load_builds_cache(): # Load the full cached builds list
    if setting("autozipsize") != "true":
        return []

    if os.path.exists(cache_file):
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception as e:
            xbmc.log(f"[LatinBoy] Failed to read builds cache: {e}", xbmc.LOGINFO)

    return []


def parse_builds_response(response): #Parse builds from json/xml/txt response
    builds = []

    if '"name":' in response or "'name':" in response:
        builds = json.loads(response)['builds']

    elif '<name>' in response:
        xml = XmlParser(response)
        builds = xml.parse_builds()

    elif 'name=' in response:
        text = TextParser(response)
        builds = text.parse_builds()

    return builds


def main_menu():
    xbmcplugin.setPluginCategory(HANDLE, COLOR1('Menú Principal'))
    
    add_dir(COLOR1(f"<><> [B]Bienvenido al Latin Boy Wizard[/B] <><>"), '', '', addon_icon, addon_fanart, COLOR2(f'Latin Boy Wizard v{addon_ver}\n\nTiempo activo:  {uptime}\nTiempo activo total:  {total_uptime}'), isFolder=False)
    
    if UPDATE_VERSION > BUILD_VERSION:
        add_dir(COLOR3(f'[B]¡¡¡Actualización disponible!!![/B]   [{BUILD_NAME} v{UPDATE_VERSION}]'), '', 41, addon_icon, addon_fanart, COLOR2("¡Tienes una actualización disponible! Haz clic aquí o abre el menú de builds para instalarla."), isFolder=False)
        
    elif CURRENT_BUILD not in ['No Build Installed', 'No Build']:
        add_dir(COLOR4(f'Configuración instalada:   {CURRENT_BUILD} v{BUILD_VERSION}'), '', '', addon_icon, addon_fanart, COLOR2(f'Fecha instalación:  {inst_date}\nSkin:  {cur_skin}\n\nComplementos de vídeo  [{vid_list}]\nComplementos de programa  [{prg_list}]\nRepositorios  [{repo_list}]'), isFolder=False)

    add_dir(COLOR4(f'Versión de Kodi:  v{kodi_ver}'), '', '', addon_icon, addon_fanart, COLOR2(f'Fecha de lanzamiento: {build_date}\n\nVersión completa:\n{build_ver}'), isFolder=False)
    
    if buildfile not in ['', 'http://', 'http://CHANGEME/']:
        add_dir(COLOR2(f'Menú de builds  ({NUM_BUILDS} builds)'), '', 1, addon_icon, addon_fanart, COLOR2("Instalar un Build"), isFolder=True)
    else:
        add_dir(COLOR2("Menú de Builds"), '', 1, addon_icon, addon_fanart, COLOR2("Instalar un Build"), isFolder=True)

    add_dir(COLOR2("Mantenimiento"), '', 5, addon_icon, addon_fanart, COLOR2("Herramientas de Mantenimiento"), isFolder=True)
    add_dir(COLOR2("Herramientas del Wizard"), '', 36, addon_icon, addon_fanart, COLOR2("Herramientas del Wizard"), isFolder=True)
    add_dir(COLOR2("Notificación"), '', 34, addon_icon, addon_fanart, COLOR2("Abrir el diálogo de notificaciones"), isFolder=False)
    
    if videos_url not in ('', 'http://', 'http://CHANGEME'):
        add_dir(COLOR2('Vídeos'), videos_url, 40, addon_icon, addon_fanart, COLOR2('Vídeos'), isFolder=True)

    if changelog_dir not in ['', 'http://', 'http://CHANGEME/'] and CURRENT_BUILD not in ['No Build Installed', 'No Build']:
        add_dir(COLOR2(f'Ver registro de cambios'), '', 35, addon_icon, addon_fanart, COLOR2(f'Ver el registro de cambios de tu configuración\n\nConfiguración actual:  {CURRENT_BUILD} v{BUILD_VERSION}'), isFolder=False)

    add_dir(COLOR2('Ver registro'),'', 26, addon_icon,addon_fanart,COLOR2('Ver el registro de Kodi'), isFolder=False)
    add_dir(COLOR2("Ajustes"), '', 9, addon_icon, addon_fanart, COLOR2("Abrir el menú de ajustes"), isFolder=False)


def build_menu():
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmcplugin.setPluginCategory(HANDLE, "Menú de Builds")

    builds = load_builds_cache()

    if builds:
        xbmc.log("[LatinBoy] Loaded builds from builds_cache.json", xbmc.LOGINFO)
    else:
        xbmc.log("[LatinBoy] Builds cache unavailable - loading buildfile fallback", xbmc.LOGINFO)
        try:
            response = get_page(buildfile)
        except:
            xbmcgui.Dialog().notification(addon_name, '¡No hay archivo de builds!', addon_icon, 3000)
            return

        builds = parse_builds_response(response)

    if not builds:
        xbmcgui.Dialog().notification(addon_name, '¡No se encontraron builds!', addon_icon, 3000)
        return

    for build in builds:
        name = build.get('name', "Nombre desconocido")
        version = build.get('version', '')
        kodiversion = build.get('kodi')
        url = build.get('url', '')
        if setting("autozipsize") == "true":
            buildsize = build.get('size', '0MB')
        else:
            buildsize = ''
        if url.startswith('https://www.dropbox.com'):
            url = url.replace('dl=0', 'dl=1')
        icon = build.get('icon', addon_icon)
        fanart = build.get('fanart', addon_fanart)
        description = build.get('description', "Sin descripción disponible.")
        preview = build.get('preview', None)

        if url.endswith('.xml') or url.endswith('.json') or url.endswith('.txt'):
            add_dir(COLOR2(name), url, 1, icon, fanart, COLOR2(description),
                    name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=True)

        elif '20' in kodi_ver and version == '' and kodiversion == 'K20':
            add_dir(COLOR2(f'{name}'), url, '', icon, fanart, description, name2=name, isFolder=False)

        elif '21' in kodi_ver and version == '' and kodiversion == 'K21':
            add_dir(COLOR2(f'{name}'), url, '', icon, fanart, description, name2=name, isFolder=False)

        elif '22' in kodi_ver and version == '' and kodiversion == 'K22':
            add_dir(COLOR2(f'{name}'), url, '', icon, fanart, description, name2=name, isFolder=False)
            
        elif '20' in kodi_ver and kodiversion == 'K20':
            if setting("autozipsize") == "true":
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version} / {buildsize})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            else:
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1("Vista previa de" + ' ' + name + ' ' + "v" + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)
                
        elif '21' in kodi_ver and kodiversion == 'K21':
            if setting("autozipsize") == "true":
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version} / {buildsize})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            else:
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1("Vista previa de" + ' ' + name + ' ' + "v" + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)
                
        elif '22' in kodi_ver and kodiversion == 'K22':
            if setting("autozipsize") == "true":
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version} / {buildsize})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            else:
                add_dir(COLOR2(f'[B]{name}[/B] -- (v{version})'), url, 3, icon, fanart, description,
                        name2=name, version=version, kodi=kodiversion, size=buildsize, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1("Vista previa de" + ' ' + name + ' ' + "v" + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)

        elif not any(x in kodiversion for x in kodi_versions):
            add_dir(COLOR2(f'{name} (v{version})'), url, 3, icon, fanart, description,
                    name2=name, version=version, isFolder=False)
            if preview not in (None, '', 'http://', 'https://'):
                add_dir(COLOR1("Vista previa de" + ' ' + name + ' ' + "v" + ' ' + version),
                        preview, 2, icon, fanart, COLOR2(description), name2=name, version=version, isFolder=False)
                

def submenu_maintenance():
    stats = quick_stats()

    packagesize   = stats["packagesize"]
    thumbnailsize = stats["thumbnailsize"]
    cleanup       = stats["cleanup"]
    buildsize     = stats["buildsize"]

    add_dir(COLOR1('<><> [B]Revisión de Kodi[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)

    if CURRENT_BUILD not in ['No Build Installed', 'No Build']:
        add_dir(COLOR4(f'Tamaño total del build:  {buildsize}MB'),'','',addon_icon,addon_fanart, COLOR2('Tamaño total en disco de tu build instalado'), isFolder=False)

    if cleanup > 400:
        add_dir(COLOR3(f'Limpiar ahora:  {cleanup}MB'),'','',addon_icon,addon_fanart, COLOR2('La limpieza total supera 250MB'), isFolder=False)
    else:
        add_dir(COLOR4(f'Disponible para limpiar:  {cleanup}MB'),'','',addon_icon,addon_fanart, COLOR2('Total de datos disponibles para limpiar'), isFolder=False)

    add_dir(COLOR1('<><> Limpiar Kodi <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)

    add_dir(COLOR2(f'Limpiar todo  [{cleanup}MB]'),'',31,addon_icon,addon_fanart,COLOR2('Limpia las carpetas de paquetes y miniaturas para liberar espacio.'),isFolder=False)
    add_dir(COLOR2(f'Limpiar paquetes  [{packagesize}MB]'),'',6,addon_icon,addon_fanart,COLOR2("Limpia la carpeta de paquetes para liberar espacio."),isFolder=False)
    add_dir(COLOR2(f'Limpiar miniaturas  [{thumbnailsize}MB]'),'',7,addon_icon,addon_fanart,COLOR2("Elimina la carpeta de miniaturas y base de datos de texturas. Reinicia Kodi para regenerarlas."),isFolder=False)
    
    '''disk = quick_disk_stats()

    total_space = disk["total_space"]
    used_space  = disk["used_space"]
    free_space  = disk["free_space"]
    used_perc   = disk["used_perc"]
    free_perc   = disk["free_perc"]
    
    add_dir(COLOR1('<><> [B]System Check-Up[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    if total_space > 1024:
        add_dir(COLOR2(f'Capacity:  {round((total_space / 1024), 2)}GB  [100%]'), '', '', addon_icon, addon_fanart, COLOR2('Total size of your HDD/SSD'), isFolder=False)
    else:
        add_dir(COLOR2(f'Capacity:  {round((total_space))}MB'), '', '', addon_icon, addon_fanart, COLOR2('Total size of your HDD/SSD'), isFolder=False)
    if used_space > 1024:
        add_dir(COLOR2(f'Used Space:  {round((used_space / 1024), 2)}GB  [{used_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total used HDD/SSD space'), isFolder=False)
    else:
        add_dir(COLOR2(f'Used Space:  {round((used_space))}MB  [{used_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total used HDD/SSD space'), isFolder=False)
    if free_space > 1024:
        add_dir(COLOR2(f'Free Space:  {round((free_space / 1024), 2)}GB  [{free_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total free HDD/SSD space'), isFolder=False)
    else:
        add_dir(COLOR2(f'Free Space:  {round((free_space))}MB  [{free_perc}]'), '', '', addon_icon, addon_fanart, COLOR2('Total free HDD/SSD space'), isFolder=False)'''


def submenu_tools():   
    add_dir(COLOR1('<><> [B]Copia de seguridad y restauración[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    add_dir(COLOR2('Copia de seguridad/Restaurar build'),'',12,addon_icon,addon_fanart, COLOR2('Copia de seguridad y restauración de build'))
    add_dir(COLOR2('Copia de seguridad/Restaurar ajustes de GUI y Skin'),'',19,addon_icon,addon_fanart,COLOR2('Copia de seguridad/Restaurar ajustes de GUI y Skin'))
    add_dir(COLOR2('Restaurar Kodi a valores predeterminados (Inicio Limpio)'), '', 4, addon_icon, addon_fanart, COLOR2("Borra todos los datos de tu build actual. Esta acción no se puede deshacer."), isFolder=False)
    
    add_dir(COLOR1('<><> [B]Lista blanca de complementos[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    add_dir(COLOR2('Añadir a la lista blanca'),'',11,addon_icon,addon_fanart,COLOR2("Añade complementos a la lista blanca para que no sean eliminados durante las actualizaciones."), isFolder=False)
    add_dir(COLOR2('Eliminar de la lista blanca'),'', 33, addon_icon,addon_fanart,COLOR2('Eliminar elementos de la lista blanca'), isFolder=False)
    
    add_dir(COLOR1('<><> [B]Herramientas del Wizard[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''),isFolder=False)
    if chk_splash == None or chk_splash == 'true':
        add_dir(COLOR2('Desactivar pantalla de inicio de Kodi'),'',29,addon_icon,addon_fanart,COLOR2("Activar/Desactivar pantalla de inicio de Kodi"),isFolder=False)
    else:
        add_dir(COLOR2('Activar pantalla de inicio de Kodi'),'',29,addon_icon,addon_fanart,COLOR2("Activar/Desactivar pantalla de inicio de Kodi"),isFolder=False)
    if chk_skin_override():
        add_dir(COLOR2('Activar protección de skin'),'',30,addon_icon,addon_fanart,COLOR2("Activa esto para proteger el skin de tu build y evitar que vuelva a Estuary si el archivo GUI se corrompe."),isFolder=False)
    else:
        add_dir(COLOR2('Desactivar protección de skin'),'',30,addon_icon,addon_fanart,COLOR2("Activa esto para proteger el skin de tu build y evitar que vuelva a Estuary si el archivo GUI se corrompe."),isFolder=False)
    if '21' or '22' in kodi_ver:
        add_dir(COLOR2("Ajustes de caché de vídeo"),'',8,addon_icon,addon_fanart,COLOR2("Ajustes preestablecidos de caché según la RAM de tu dispositivo."),isFolder=False)
        add_dir(COLOR2('Ver ajustes de caché'),'',75,addon_icon,addon_fanart,COLOR2('Ver ajustes de caché de vídeo. Requiere nivel de ajustes GUI avanzado o superior.'), isFolder=False)
    add_dir(COLOR2('Prueba de velocidad'),'',28,addon_icon,addon_fanart,COLOR2('Realizar una prueba de velocidad de Internet'), isFolder=False)


def backup_restore():
    xbmcplugin.setPluginCategory(HANDLE, COLOR1('Copia de seguridad/Restauración'))
    add_dir(COLOR1('<><> [B]Copia de seguridad/Restauración[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''), isFolder=False)
    add_dir(COLOR2('Copia de seguridad de build'),'',13,addon_icon,addon_fanart, COLOR2('Copia de seguridad de build'), isFolder=False)
    add_dir(COLOR2('Restaurar copia de seguridad'),'',14, addon_icon,addon_fanart, COLOR2('Restaurar copia de seguridad'))
    add_dir(COLOR2('Cambiar ubicación de la carpeta de copias de seguridad'),'',16,addon_icon,addon_fanart, COLOR2('Cambia la ubicación donde se guardarán y accederán las copias de seguridad.'), isFolder=False)
    add_dir(COLOR2('Restablecer ubicación de la carpeta de copias de seguridad'),'',17,addon_icon,addon_fanart, COLOR2('Establece la ubicación de copias de seguridad a su valor predeterminado.'), isFolder=False)


def restore_gui_skin():
    add_dir(COLOR1('<><> [B]Copia de seguridad/Restaurar ajustes de GUI y Skin[/B] <><>'),'','',addon_icon,addon_fanart, COLOR1(''), isFolder=False)
    add_dir(COLOR2('Copia de seguridad de ajustes de GUI y Skin'),'',22,addon_icon,addon_fanart,COLOR2('Copia de seguridad de ajustes de GUI y Skin'), isFolder=False)
    add_dir(COLOR2('Restaurar ajustes de GUI'),'',23, addon_icon,addon_fanart, COLOR2('Restaurar tus ajustes de GUI'), isFolder=False)
    add_dir(COLOR2('Restaurar ajustes de Skin'),'',24, addon_icon,addon_fanart, COLOR2('Restaurar tus ajustes de Skin'), isFolder=False)
    add_dir(COLOR2('Restaurar ajustes de GUI predeterminados del build'),'',20,addon_icon,addon_fanart,COLOR2('Restaurar ajustes de GUI'), isFolder=False)
    add_dir(COLOR2('Restaurar ajustes de Skin predeterminados del build'),'',21, addon_icon,addon_fanart, COLOR2('Restaurar ajustes de Skin'), isFolder=False)
