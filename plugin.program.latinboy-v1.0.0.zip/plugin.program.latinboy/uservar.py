import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/latinboykodi/latinboykodi.github.io/main/builds/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/latinboykodi/latinboykodi.github.io/main/builds/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
